#!/bin/bash

docker build . --rm -t jasper