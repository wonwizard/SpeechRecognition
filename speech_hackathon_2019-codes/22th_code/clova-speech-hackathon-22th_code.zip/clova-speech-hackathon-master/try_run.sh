#!/bin/sh

while true
do
	./run_nsml.sh config/cfg3/lstm_deepenc_small_reg2.cfg3.json
done
