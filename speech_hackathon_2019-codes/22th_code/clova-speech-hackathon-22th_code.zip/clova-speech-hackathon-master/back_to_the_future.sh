#!/bin/sh


while true
do
	echo "Lets try testing!"
	nsml submit team161/sr-hack-2019-dataset/921 best
	sleep 61m
	nsml submit team161/sr-hack-2019-dataset/945 best
	sleep 61m
	nsml submit team161/sr-hack-2019-dataset/948 best
	sleep 61m
done
