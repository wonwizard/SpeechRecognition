#!/bin/sh


while true
do
	echo "Lets try testing!"
	nsml submit team161/sr-hack-2019-50000/1 best
	sleep 60
done
