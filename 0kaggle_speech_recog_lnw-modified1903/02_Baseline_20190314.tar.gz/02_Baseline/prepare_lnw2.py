# -*- encoding : utf-8 -*-
#
# lnw modified
#
#
#/home/neoadmin/kaggle_speech_recog/competitions_data/
# /train/noise/*.wav
# /train/voice/*.wav
# /val/noise/*.wav
# /val/voice/*.wav
#실행 디렉토리 아래
# ./input/trnnoise
# ./input/trnvoice
# ./input/valnoise
# ./input/valvoice
#




# 10개의 label과 데이터 경로를 지정한다
# lnw modified voice noise 로 변경
labels = ['voice', 'noise', 'up', 'down', 'left', 'right', 'on', 'off', 'stop', 'go']
#lnw modified 
#data_path = '~/.kaggle/competitions/tensorflow-speech-recognition-challenge' 
data_path = '/home/neoadmin/kaggle_speech_recog/competitions_data'

from glob import glob
import random
import os
import numpy as np
#lnw
from datetime import datetime
import wave


#setting. lnw add. milleseconds data.py 파일안에 설정도 변경시 변경필요
sliceTime = 400

#lnw start time 
start_time = datetime.now()
print("Start time : "+str(start_time))

SEED = 2018


# 리스트를 랜덤하게 셔플하는 함수이다
def random_shuffle(lst):
    random.seed(SEED)
    random.shuffle(lst)
    return lst

#lnw add wave file slice 함수 
def wavSlice(fileName,saveDir,sliceTime)
   #fileName='test2.wav'
   # slice seconds, 400ms = 400
   #sliceTime = 400

   wavfile = wave.open(fileName)
   frameRate = wavfile.getframerate()
   # frames per ms
   fpms = frameRate / 1000 
   numFrames = wavfile.getnframes()
   width = wavfile.getsampwidth()

   sliceTime = 1000*width
   frames = wavfile.readframes(numFrames)
   sliceNumFrames = int(fpms * sliceTime)

   x=0
   while x+sliceNumFrames<=numFrames:
       curFrames= frames[x:x+sliceNumFrames]
       x=x+sliceNumFrames
       fileName=fileName.split('/')[-1]
       writeFilname = saveDir+fileName[:-4]+'-'+str(x)+fileName[-4:]
       write = wave.open(writeFilname,'w')
       write.setparams((wavfile.getnchannels(), width, frameRate, sliceNumFrames, wavfile.getcomptype(), wavfile.getcompname()))
       write.writeframes(curFrames)



# 텍스트 파일을 저장할 폴더를 생성한다.
if not os.path.exists('input'):
    os.mkdir('input')

# lnw add mkae noise slice files directory, voice slice files directory 
if not os.path.exists('input/trnnoise'):
    os.mkdir('input/trnnoise')
if not os.path.exists('input/trnvoice'):
    os.mkdir('input/trnvoice')
if not os.path.exists('input/valnoise'):
    os.mkdir('input/valnoise')
if not os.path.exists('input/valvoice'):
    os.mkdir('input/valvoice')

# 훈련 데이터 전체 trn_all.txt에 저장한다
trn_all = []
trn_all_file = open('input/trn_all.txt', 'w')
val_all = []
val_all_file = open('input/val_all.txt', 'w')

# 제공된 훈련 데이터 경로를 모두 읽어온다
#files = glob(data_path + '/train/audio/*/*.wav')

#lnw add. read train datas
noiseTrnFiles = glob(data_path + '/train/noise/*.wav')
voiceTrnFiles = glob(data_path + '/train/voice/*.wav')
noiseValFiles = glob(data_path + '/val/noise/*.wav')
voiceValFiles = glob(data_path + '/val/voice/*.wav')
#lnw add. slice files 
for f in noiseTrnFiles:
    fileName = nf.split('/')[-1] 
    saveDir = 'input/trnnoise' 
    wavSlice(fileName,saveDir,sliceTime)
for f in voiceTrnFiles:
    fileName = vf.split('/')[-1]
    saveDir = 'input/trnvoice'
    wavSlice(fileName,saveDir,sliceTime)
for f in noiseValFiles:
    fileName = nf.split('/')[-1]
    saveDir = 'input/valnoise'
    wavSlice(fileName,saveDir,sliceTime)
for f in voiceValFiles:
    fileName = vf.split('/')[-1]
    saveDir = 'input/valvoice'
    wavSlice(fileName,saveDir,sliceTime)


#lnw add. read sliced train and val datas
noiseTrnFiles = glob('input/trnnoise/*.wav')
voiceTrnFiles = glob('input/trnvoice/*.wav')
noiseValFiles = glob('input/valnoise/*.wav')
voiceValFiles = glob('input/valvoice/*.wav')

for f in noiseTrnFiles:
      label = 'noise'
      speaker = 'none'
      trn_all.append((label, speaker, f))
      trn_all_file.write('{},{},{}\n'.format(label, speaker, f))
for f in voiceTrnFiles:
      label = 'voice'
      speaker = 'none'
      trn_all.append((label, speaker, f))
      trn_all_file.write('{},{},{}\n'.format(label, speaker, f))
for f in noiseValFiles:
      label = 'noise'
      speaker = 'none'
      val_all.append((label, speaker, f))
      val_all_file.write('{},{},{}\n'.format(label, speaker, f))
for f in voiceValFiles:
      label = 'voice'
      speaker = 'none'
      val_all.append((label, speaker, f))
      val_all_file.write('{},{},{}\n'.format(label, speaker, f))


trn_all_file.close()
val_all_file.close()



# 교차 검증용 파일을 생성한다
trn_file = open('input/trn.txt', 'w')
val_file = open('input/val.txt', 'w')
for (label, speaker, path) in trn_all:
    if speaker not in speaker_val:
        trn_file.write('{},{},{}\n'.format(label, speaker, path))
    else:
        val_file.write('{},{},{}\n'.format(label, speaker, path))
trn_file.close()
val_file.close()

# 테스트 데이터에 대해서도 텍스트 파일을 생성한다
tst_all_file = open('input/tst.txt', 'w')
files = glob(data_path + '/test/audio/*.wav')
for f in files:
    tst_all_file.write(',,{}\n'.format(f))
tst_all_file.close()

#lnw end time, duration
end_time = datetime.now()
print("End time : "+str(end_time))
print('Duration: {}'.format(end_time - start_time))

