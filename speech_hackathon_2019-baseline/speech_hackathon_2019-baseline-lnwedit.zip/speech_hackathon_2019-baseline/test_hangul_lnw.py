#-*- coding: utf-8 -*-


#rf = open("./sample_dataset/train/train_data2/KsponSpeech_000001.txt",'rt',encoding='utf-8')
#rf = open("./test.txt",'rt',encoding='utf-8')
rf = open("./test.txt",'rt',encoding='cp949')
#rf=open("./testutf8.txt")
rline = rf.readline()

print (rline)


